"""Shared code for the thesis notebooks (Layers 2, 4, 5, 6).

Keep this file in the same folder as the notebooks. Saved models refer to the classes defined here,
so any notebook that loads a saved model must `import thesis_pipeline` first.
"""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline

EXT_COLS = ["EXT_SOURCE_1", "EXT_SOURCE_2", "EXT_SOURCE_3"]
CAT_COLS = ["NAME_INCOME_TYPE", "OCCUPATION_TYPE"]
HISTORY_PREFIXES = ("INST_", "POS_", "CC_", "BUREAU_", "BB_", "PREV_")
WINSOR_COLS = ["AMT_INCOME_TOTAL", "ANNUITY_TO_INCOME", "CREDIT_TO_GOODS_RATIO", "CC_RECENT_UTIL", "AMT_CREDIT"]

# Second tag for Q2 (traditional vs alternative vs socio-economic).
# PROPOSED grouping: confirm with the adviser before reporting Q2.
DATA_TYPE = {
    # Traditional financial / credit-bureau information
    "AMT_INCOME_TOTAL": "Traditional", "ANNUITY_TO_INCOME": "Traditional",
    "CREDIT_TO_GOODS_RATIO": "Traditional", "CREDIT_TO_MEDIAN": "Traditional",
    "HAS_BUREAU": "Traditional", "HAS_BUREAU_BALANCE": "Traditional",
    "BUREAU_ACTIVE_COUNT": "Traditional", "BUREAU_ACTIVE_CREDIT_SUM": "Traditional",
    "BUREAU_ACTIVE_DEBT": "Traditional", "BUREAU_MAX_DAYS_OVERDUE": "Traditional",
    "BUREAU_TOTAL_OVERDUE": "Traditional", "BB_WORST_STATUS": "Traditional",
    "FLAG_OWN_CAR": "Traditional", "FLAG_OWN_REALTY": "Traditional",
    # Alternative / behavioral (in-house repayment and application behavior)
    "INST_PCT_LATE": "Alternative", "INST_PCT_MISSED": "Alternative", "INST_MEAN_DELAY": "Alternative",
    "INST_COUNT": "Alternative", "POS_MAX_DPD": "Alternative", "POS_PCT_MONTHS_LATE": "Alternative",
    "POS_PCT_MONTHS_30PLUS": "Alternative", "POS_MONTHS_COUNT": "Alternative",
    "CC_MAX_DPD": "Alternative", "CC_PCT_MONTHS_LATE": "Alternative", "CC_RECENT_UTIL": "Alternative",
    "PREV_PCT_APPROVED": "Alternative", "PREV_PCT_REFUSED": "Alternative", "PREV_PCT_CANCELED": "Alternative",
    "PRIOR_APP_COUNT": "Alternative", "HAS_POS_HISTORY": "Alternative", "HAS_CC_HISTORY": "Alternative",
    "HAS_INST_HISTORY": "Alternative",
    # Socio-economic
    "DAYS_EMPLOYED": "Socio-economic", "DAYS_REGISTRATION": "Socio-economic",
    "NAME_INCOME_TYPE": "Socio-economic", "OCCUPATION_TYPE": "Socio-economic",
    "REGION_POPULATION_RELATIVE": "Socio-economic", "REGION_RATING_CLIENT": "Socio-economic",
    "REGION_RATING_CLIENT_W_CITY": "Socio-economic",
    # External bureau-type scores (only in the "matrix+ext" comparison)
    "EXT_SOURCE_1": "External score", "EXT_SOURCE_2": "External score", "EXT_SOURCE_3": "External score",
}


# --------------------------------------------------------------------------- transformers
class Winsorizer(BaseEstimator, TransformerMixin):
    """Clip columns to percentiles learned in fit() (training data only)."""
    def __init__(self, cols=None, lower=0.01, upper=0.99):
        self.cols, self.lower, self.upper = cols, lower, upper

    def fit(self, X, y=None):
        self.bounds_ = {c: (X[c].quantile(self.lower), X[c].quantile(self.upper)) for c in self.cols}
        return self

    def transform(self, X):
        X = X.copy()
        for c, (lo, hi) in self.bounds_.items():
            X[c] = X[c].clip(lo, hi)
        return X


class CreditToMedian(BaseEstimator, TransformerMixin):
    """AMT_CREDIT / median(AMT_CREDIT), median learned in fit() (training data only)."""
    def fit(self, X, y=None):
        self.median_ = X["AMT_CREDIT"].median() if "AMT_CREDIT" in X else None
        return self

    def transform(self, X):
        if getattr(self, "median_", None) is None or "AMT_CREDIT" not in X:
            return X                      # feature subset without AMT_CREDIT: nothing to do
        X = X.copy()
        X["AMT_CREDIT"] = X["AMT_CREDIT"] / self.median_
        return X.rename(columns={"AMT_CREDIT": "CREDIT_TO_MEDIAN"})


# --------------------------------------------------------------------------- pipeline
def column_groups(columns):
    """Split input columns into history / other numeric / categorical (names after CreditToMedian)."""
    columns = list(columns)
    cat = [c for c in CAT_COLS if c in columns]
    num = [("CREDIT_TO_MEDIAN" if c == "AMT_CREDIT" else c) for c in columns if c not in cat]
    hist = [c for c in num if c.startswith(HISTORY_PREFIXES)]
    other = [c for c in num if c not in hist]
    winsor = [c for c in WINSOR_COLS if c in columns]
    return dict(cat=cat, hist=hist, other=other, winsor=winsor)


def make_preprocessor(groups, scale=False):
    def num(indicator):
        steps = [("impute", SimpleImputer(strategy="median", add_indicator=indicator))]
        if scale:
            steps.append(("scale", StandardScaler()))
        return Pipeline(steps)
    return ColumnTransformer([
        ("hist", num(False), groups["hist"]),            # missing = no records; HAS_* flag says it
        ("num", num(True), groups["other"]),             # other blanks get a missing-indicator
        ("cat", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("ohe", OneHotEncoder(handle_unknown="infrequent_if_exist", sparse_output=False,
                                  min_frequency=0.01)),
        ]), groups["cat"]),
    ], remainder="drop", verbose_feature_names_out=False)


def make_pipeline(model, groups, scale=False, use_smote=False, seed=42):
    """winsorize -> loan size vs median -> impute / encode (-> scale) -> (SMOTE) -> model."""
    steps = [("winsor", Winsorizer(cols=groups["winsor"])),
             ("credit_median", CreditToMedian()),
             ("prep", make_preprocessor(groups, scale))]
    if use_smote:
        steps.append(("smote", SMOTE(sampling_strategy=0.5, random_state=seed)))
    steps.append(("model", model))
    return Pipeline(steps)


def transform_for_model(pipe, X):
    """Apply the fitted preprocessing steps (SMOTE skipped) to get the matrix the model sees."""
    for name, step in pipe.steps[:-1]:
        if name == "smote":
            continue
        X = step.transform(X)
    return X


# --------------------------------------------------------------------------- SHAP
def source_feature(out_name, features):
    """Map a model column (one-hot level, missing-indicator) back to its input feature."""
    if out_name.startswith("missingindicator_"):
        out_name = out_name[len("missingindicator_"):]
    if out_name in features:
        return out_name
    for f in CAT_COLS:
        if out_name.startswith(f + "_"):
            return f
    return out_name


def shap_by_feature(pipe, X_eval, kind, X_background=None, n_background=2000, seed=42):
    """SHAP values per applicant (rows of X_eval) and per INPUT feature. Columns created by the pipeline
    (one-hot levels, missing-indicators) are summed back to their source feature, per row."""
    import shap
    Ze = transform_for_model(pipe, X_eval)
    names = pipe.named_steps["prep"].get_feature_names_out()
    model = pipe.named_steps["model"]
    if kind == "linear":
        Xb = X_background.sample(min(n_background, len(X_background)), random_state=seed)
        Zb = transform_for_model(pipe, Xb)
        masker = shap.maskers.Independent(Zb, max_samples=len(Zb))   # use all background rows, not 100
        sv = shap.LinearExplainer(model, masker).shap_values(Ze)
    elif hasattr(model, "get_booster"):
        # XGBoost: built-in exact TreeSHAP (same values as shap.TreeExplainer; avoids a known
        # shap / xgboost>=3 incompatibility). Last column is the bias term.
        import xgboost as xgb
        sv = model.get_booster().predict(xgb.DMatrix(Ze), pred_contribs=True)[:, :-1]
    else:
        sv = shap.TreeExplainer(model).shap_values(Ze, check_additivity=False)
    if isinstance(sv, list):          # older shap: one array per class
        sv = sv[1]
    sv = np.asarray(sv)
    if sv.ndim == 3:                  # newer shap: (rows, features, classes)
        sv = sv[:, :, 1]
    features = [("CREDIT_TO_MEDIAN" if c == "AMT_CREDIT" else c) for c in X_eval.columns]
    # Sum a feature's columns per row FIRST, then take |.| later; otherwise categorical features with
    # many levels look more important than they are.
    per_row = pd.DataFrame(sv, columns=names).T.groupby([source_feature(c, features) for c in names]).sum().T
    per_row.index = X_eval.index
    return per_row


def shap_importance(pipe, X_eval, kind, n=2000, X_background=None, seed=42):
    """Mean |SHAP| per input feature on a random sample of n rows of X_eval."""
    Xe = X_eval.sample(min(n, len(X_eval)), random_state=seed)
    return shap_by_feature(pipe, Xe, kind, X_background=X_background, n_background=n, seed=seed).abs().mean(axis=0)


# --------------------------------------------------------------------------- stability (Q3)
def kendalls_w(importance):
    """Kendall's coefficient of concordance. Rows = raters (folds or models), columns = features.
    1 = identical rankings, 0 = no agreement. Tie correction included."""
    R = importance.rank(axis=1, ascending=False)
    m, n = R.shape
    S = ((R.sum(axis=0) - m * (n + 1) / 2) ** 2).sum()
    T = 0.0
    for _, row in R.iterrows():
        counts = row.value_counts()
        T += ((counts ** 3) - counts).sum()
    return 12 * S / (m ** 2 * (n ** 3 - n) - m * T)


def topk_overlap(importance, k=10):
    """Mean pairwise Jaccard overlap of the top-k features between raters (rows)."""
    tops = [set(row.nlargest(k).index) for _, row in importance.iterrows()]
    pairs = [(i, j) for i in range(len(tops)) for j in range(i + 1, len(tops))]
    return float(np.mean([len(tops[i] & tops[j]) / len(tops[i] | tops[j]) for i, j in pairs]))


def best_f1_threshold(y_true, proba):
    """Cutoff that maximizes F1 (chosen on cross-validation predictions, never on the test set)."""
    from sklearn.metrics import precision_recall_curve
    p, r, t = precision_recall_curve(y_true, proba)
    f1 = 2 * p * r / np.clip(p + r, 1e-12, None)
    i = int(np.nanargmax(f1[:-1]))
    return float(t[i]), float(f1[i])


# --------------------------------------------------------------------------- Layer 5-6 helpers
def input_name(col):
    """Name used in FEATURE_MAP / DATA_TYPE for an input column."""
    return "CREDIT_TO_MEDIAN" if col == "AMT_CREDIT" else col


class FastAUC:
    """AUC-ROC of a fixed prediction vector under bootstrap weights (row counts), O(n) per resample."""
    def __init__(self, y, p):
        y = np.asarray(y)
        u, self.inv = np.unique(np.asarray(p), return_inverse=True)
        self.k = len(u)
        self.pos = (y == 1).astype(float)
        self.neg = (y == 0).astype(float)

    def __call__(self, w=None):
        w = np.ones(len(self.inv)) if w is None else w
        P = np.bincount(self.inv, weights=w * self.pos, minlength=self.k)
        N = np.bincount(self.inv, weights=w * self.neg, minlength=self.k)
        below = np.cumsum(N) - N
        return float((P * (below + 0.5 * N)).sum() / (P.sum() * N.sum()))


def bootstrap_counts(y, b, seed=42):
    """Row counts for bootstrap resample b: stratified (defaults and non-defaults resampled separately),
    reproducible, and identical across models/features so comparisons are paired."""
    y = np.asarray(y)
    rng = np.random.default_rng([seed, b])
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    idx = np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))])
    return np.bincount(idx, minlength=len(y)).astype(float)


def weighted_metrics(y, proba, cutoff, w=None):
    """AUC, PR-AUC, F1, precision, recall, accuracy (optionally with bootstrap weights)."""
    from sklearn.metrics import average_precision_score
    y = np.asarray(y); proba = np.asarray(proba)
    w = np.ones(len(y)) if w is None else w
    pred = proba >= cutoff
    tp = (w * (pred & (y == 1))).sum(); fp = (w * (pred & (y == 0))).sum()
    fn = (w * (~pred & (y == 1))).sum(); tn = (w * (~pred & (y == 0))).sum()
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    return dict(auc=FastAUC(y, proba)(w), pr_auc=average_precision_score(y, proba, sample_weight=w),
                f1=2 * prec * rec / (prec + rec) if prec + rec else 0.0, precision=prec, recall=rec,
                accuracy=(tp + tn) / w.sum(), flag_rate=(tp + fp) / w.sum(),
                fpr=fp / (fp + tn) if fp + tn else 0.0)


def bh_adjust(pvalues):
    """Benjamini-Hochberg adjusted p-values (q-values). Reject H0 where adjusted p <= q (e.g. 0.05)."""
    p = np.asarray(pvalues, dtype=float)
    m = len(p)
    order = np.argsort(p)
    ranked = p[order] * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(m)
    out[order] = np.minimum(adj, 1.0)
    return out


def ale_edges(x, bins=20):
    """Quantile grid for ALE (duplicates removed, so discrete features get fewer intervals)."""
    xv = pd.Series(x).dropna().astype(float).values
    return np.unique(np.quantile(xv, np.linspace(0, 1, bins + 1)))


def ale_1d(predict, X, feature, bins=20, edges=None):
    """First-order Accumulated Local Effects (Apley & Zhu, 2020) of one numeric feature.
    Returns (grid values, centered ALE in probability units). Rows with the feature missing are skipped."""
    x = X[feature]
    mask = x.notna().values
    Xm = X[mask]
    xv = x[mask].astype(float).values
    if edges is None:
        edges = ale_edges(xv, bins)
    xv = np.clip(xv, edges[0], edges[-1])
    if len(edges) < 2:
        return None, None
    k = np.clip(np.searchsorted(edges, xv, side="right") - 1, 0, len(edges) - 2)
    lo, hi = Xm.copy(), Xm.copy()
    lo[feature] = edges[k]
    hi[feature] = edges[k + 1]
    diff = predict(hi) - predict(lo)
    nb = len(edges) - 1
    eff = np.bincount(k, weights=diff, minlength=nb) / np.maximum(np.bincount(k, minlength=nb), 1)
    cnt = np.bincount(k, minlength=nb)
    ale = np.concatenate([[0.0], np.cumsum(eff)])
    ale -= ((ale[:-1] + ale[1:]) / 2 * cnt).sum() / cnt.sum()     # center: average effect = 0
    return edges, ale
